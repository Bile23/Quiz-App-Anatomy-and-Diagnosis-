package com.example.nwuuser.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int score;
    RadioGroup Diagnosis;
    Button submit;
    RadioButton select;

    EditText brain,heart,polio,ringworm,ear;
    TextView point;
    String getBrain,getHeart,getEar,getRingworm,getPolio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        brain = (EditText) findViewById(R.id.edtbrain);
        heart = (EditText) findViewById(R.id.edtheart);
        ear = (EditText) findViewById(R.id.edtear);
        ringworm = (EditText) findViewById(R.id.edtringworm);
        polio = (EditText) findViewById(R.id.edtPolio);
        point=(TextView) findViewById(R.id.textView2);
        Diagnosis = findViewById(R.id.radioGroup);
        submit = findViewById(R.id.btnSubmit);

        getBrain = brain.getText().toString();
        getHeart = heart.getText().toString();
        getEar = ear.getText().toString();
        getRingworm = ringworm.getText().toString();
        getPolio = polio.getText().toString();






        if (getBrain == "BRAIN") {
            score++;
        } else
            score--;

        if (getEar == "EAR") {
            score++;
        } else
            score--;

        if (getHeart == "HEART") {
            score++;

        } else
            score--;

        if (getRingworm == "RINGWORM") {
            score++;
        } else
            score--;
        if (getPolio == "POLIO") {
            score++;
        } else
            score--;



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = Diagnosis.getCheckedRadioButtonId();
                select=(RadioButton)findViewById(radNorovirus);
                String answer = select.getText().toString();


                if (answer== "Norovirus"){
                    score++;

                } else
                    score--;
                point.setText("Score = "+score);



            }
        });
    };
};
